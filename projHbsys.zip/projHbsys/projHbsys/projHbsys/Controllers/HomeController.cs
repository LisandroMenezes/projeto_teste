﻿using projHbsys.Aplicacao;
using projHbsys.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace projHbsys.Controllers
{
    public class HomeController : Controller
    {
        private CadLivrosAplicacao cadLivrosAplicacao;
        public HomeController()
        {
            cadLivrosAplicacao = new CadLivrosAplicacao();
        }
        public ActionResult Index()
        {
            var lista = cadLivrosAplicacao.ListarTodos();
            return View(lista);
        }

        public ActionResult Cadastrar()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Cadastrar(CadLivros cadLivros)
        {
            if (ModelState.IsValid)
            {
                cadLivrosAplicacao.Salvar(cadLivros);
                return RedirectToAction("Index");
            }
            return View(cadLivros);
        }

        public ActionResult Editar(int id)
        {
            var cadLivros = cadLivrosAplicacao.ListarPorId(id);

            if (cadLivros == null)
                return HttpNotFound();

            return View(cadLivros);
        }

        [HttpPost]
        public ActionResult Editar(CadLivros cadLivros)
        {
            cadLivros.Data_cad = DateTime.Now.Date.ToString();

            if (ModelState.IsValid)
            {
                cadLivrosAplicacao.Salvar(cadLivros);
                return RedirectToAction("Index");
            }
            return View(cadLivros);
        }

        public ActionResult Detalhe(int id)
        {
            var cadLivros = cadLivrosAplicacao.ListarPorId(id);

            if (cadLivros == null)
                return HttpNotFound();

            return View(cadLivros);
        }

        public ActionResult Excluir(int id)
        {
            var cadLivros = cadLivrosAplicacao.ListarPorId(id);

            if (cadLivros == null)
                return HttpNotFound();

            return View(cadLivros);
        }

        [HttpPost, ActionName("Excluir")]
        public ActionResult ConfirmarExcluir(int id)
        {
            cadLivrosAplicacao.Excluir(id);
            return RedirectToAction("Index");
        }
    }
}
