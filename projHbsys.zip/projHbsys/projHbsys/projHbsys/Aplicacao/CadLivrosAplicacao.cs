﻿using projHbsys.Models;
using projHbsys.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace projHbsys.Aplicacao
{
    public class CadLivrosAplicacao
    {
        private readonly Contexto contexto;

        public CadLivrosAplicacao()
        {
            contexto = new Contexto();
        }

        public List<CadLivros> ListarTodos()
        {
            var cadLivros = new List<CadLivros>();
            const string strQuery = "SELECT Id, Nome, Categoria, Data_cad, Autor FROM cad_livros order by Nome asc";

            var rows = contexto.ExecutaComandoComRetorno(strQuery, null);
            foreach (var row in rows)
            {
                var tempCadLivros = new CadLivros
                {
                    Id = int.Parse(!string.IsNullOrEmpty(row["Id"]) ? row["Id"] : "0"),
                    Nome = row["Nome"],
                    Categoria = row["Categoria"],
                    Data_cad = row["Data_cad"].ToString(),
                    Autor = row["Autor"]
                };
                cadLivros.Add(tempCadLivros);
            }

            return cadLivros;
        }


        private int Inserir(CadLivros cadLivros)
        {
            const string commandText = " INSERT INTO cad_livros (Nome, Categoria, Data_cad, Autor) VALUES (@Nome, @Categoria, @Data_cad, @Autor) ";

            var parameters = new Dictionary<string, object>
            {
                {"Nome", cadLivros.Nome},
                {"Categoria", cadLivros.Categoria},
                {"Data_cad", DateTime.Now.Date},
                {"Autor", cadLivros.Autor}
            };

            return contexto.ExecutaComando(commandText, parameters);
        }

        private int Alterar(CadLivros cadLivros)
        {

            var commandText = " UPDATE cad_livros SET ";
            commandText += " Nome = @Nome, ";
            commandText += " Categoria = @Categoria, ";
            commandText += " Data_cad = @Data_cad, ";
            commandText += " Autor = @Autor ";
            commandText += " WHERE Id = @Id ";

            var parameters = new Dictionary<string, object>
            {
                {"Id", cadLivros.Id},
                {"Nome", cadLivros.Nome},
                {"Categoria", cadLivros.Categoria},
                {"Data_cad", Convert.ToDateTime(cadLivros.Data_cad)},
                {"Autor", cadLivros.Autor}

            };

            return contexto.ExecutaComando(commandText, parameters);
        }

        public void Salvar(CadLivros cadLivros)
        {
            if (cadLivros.Id > 0)
                Alterar(cadLivros);
            else
                Inserir(cadLivros);
        }

        public int Excluir(int id)
        {
            const string strQuery = "DELETE FROM cad_livros WHERE Id = @Id";
            var parametros = new Dictionary<string, object>
            {
                {"Id", id}
            };

            return contexto.ExecutaComando(strQuery, parametros);
        }

        public CadLivros ListarPorId(int id)
        {
            var cadLivros = new List<CadLivros>();
            const string strQuery = "SELECT Id, Nome, Categoria, Data_cad, Autor FROM cad_livros WHERE Id = @Id";
            var parametros = new Dictionary<string, object>
            {
                {"Id", id}
            };
            var rows = contexto.ExecutaComandoComRetorno(strQuery, parametros);
            foreach (var row in rows)
            {
                var tempCadLivros = new CadLivros
                {
                    Id = int.Parse(!string.IsNullOrEmpty(row["Id"]) ? row["Id"] : "0"),
                    Nome = row["Nome"],
                    Categoria = row["Categoria"],
                    Data_cad = row["Data_cad"].ToString(),
                    Autor = row["Autor"]
                };
                cadLivros.Add(tempCadLivros);
            }

            return cadLivros.FirstOrDefault();
        }


    }
}