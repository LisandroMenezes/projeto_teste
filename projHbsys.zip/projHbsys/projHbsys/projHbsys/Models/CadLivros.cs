﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace projHbsys.Models
{
    public class CadLivros
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Nome do Livro é obrigatório")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Categoria é obrigatório")]
        public string Categoria { get; set; }

        [Required(ErrorMessage = "Nome do autor é obrigatório")]
        public string Autor { get; set; }

        public string Data_cad { get; set; }


    }
}